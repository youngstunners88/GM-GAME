# Design Workspace

This is where the game is designed before it is built. Every mechanic, level layout, character ability, and story beat gets spec'd here first. No code. No assets. Just decisions.

## What Happens Here
- Level design documents with platform layouts, enemy placements, secret areas, and flow
- Character ability specs (run speed, jump height, double jump timing, Blaze Mode stats)
- Power-up behavior design (duration, effects, visual feedback)
- Boss fight design documents (attack patterns, arena layout, win condition)
- Lore integration with the client's three crypto projects

## Client Brand Integration
- **SmokeRing / Lil Blunt**: The hero. Chill, friendly, cool. Blaze Mode = speed boost + higher jumps + auto-puff defensive smoke clouds that damage enemies on contact.
- **DIAMONDS**: Diamond Shards power-up = temporary invincibility + damaging aura around Lil Blunt. Ethereum rings collectible = golden glowing rings with subtle Ethereum diamond vibe.
- **GoldMine**: Gold coins = standard small collectible. Tax Collector enemies = metaphor for crypto taxes and FUD. The 100-day miner concept could inspire level progression timers or milestone rewards.

## Level 1: The Smoke Realm — Design Brief
- **Biome**: Colorful, hazy, trippy forest/swamp world
- **Platforms**: Floating smoke clouds (helpful, semi-solid), giant leaves, mushroom caps, tree branches
- **Background**: Glowing flowers, distant hazy mountains, slow-drifting smoke particles
- **Secrets**: Hidden leaf-caves behind breakable mushroom blocks, underwater (swamp) coin caches
- **Flow**: Gentle tutorial opening → moderate platforming middle → vertical climb section → boss arena
- **Boss**: "The Auditor" — a giant Greedy Tax Collector creature who throws paperwork projectiles and summons Fly swarms

## Good Design Looks Like
- ASCII or markdown platform layouts showing jump distances and enemy positions
- Specific numbers: jump height (120px), run speed (200px/s), Blaze Mode duration (10s), enemy HP, damage values
- Every design doc answers: What does the player do? What is the challenge? What is the reward?
- Design docs reference client lore tastefully — the game should feel like a natural extension of the brand, not an ad
