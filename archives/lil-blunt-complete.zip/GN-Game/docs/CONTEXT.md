# Docs Workspace

This is where the game is documented for players, the client, and future developers. Marketing copy, changelogs, and build instructions live here.

## What Happens Here
- Game Design Document (GDD) summaries
- Marketing copy for social media, Discord, and the client's existing channels
- Changelogs and version release notes
- Build and export instructions (HTML5, Windows, Linux, macOS, Android)
- Client presentation materials and milestone reports

## Documentation Standards
- **Tone**: Hype-but-professional. Match the client's existing voice from the GitBooks (confident, crypto-native, community-focused).
- **Brand References**: Always mention SmokeRing, DIAMONDS, and GoldMine as the ecosystem behind the game. Not a shill — an extension of the lore.
- **Player-Facing**: Clear, concise. A new player should understand controls and objective in 60 seconds.
- **Dev-Facing**: Technical but accessible. Another developer should be able to open the Godot project and understand the architecture.

## Output Formats
- Markdown (`.md`) for internal docs and GDD sections
- Plain text (`.txt`) for in-game dialogue, UI copy, and voiceover scripts
- JSON (`.json`) for structured data: dialogue trees, item stat tables, level metadata
- CSV (`.csv`) for localization strings if multi-language support is added later

## Good Docs Look Like
- `game_manual.md` — Controls, objective, power-up explanations, enemy bestiary
- `changelog_v0.1.md` — Bullet list: Added / Changed / Fixed
- `marketing_launch_post.md` — Twitter/X thread draft with screenshots and hashtags
- `build_guide.md` — Step-by-step Godot export settings for each platform
- `client_milestone_report.md` — What was built, what's next, blockers, screenshots

## Rules
- Never promise specific token prices or investment returns in marketing copy. This is a game, not financial advice.
- Always include a disclaimer: "Lil Blunt Adventure is a community game built by fans of the SmokeRing, DIAMONDS, and GoldMine ecosystem."
- Keep lore consistent across all three projects' existing narratives.
